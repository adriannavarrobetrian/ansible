# This is a directory for configuration apache2 on ubuntu 11.10 x64
# Ubuntu keeps apache2 configuration in /etc/apache2

# WARNING: It tries to execute all files located in conf.d, that's why separate directory conf.d-noexec has been created

# Software to be installed:
# libapache2-mod-jk
# apache2
# apache2-mpm-prefork
# libapache2-mod-php5

# WARNING: Before updating apache configuration make a backup: copy original configuration to /etc/apache2-bak

# Enable SSL by making a symlink in /etc/apache2/mods-enabled to load ssl module, to ssl config:
sudo ln -s /etc/apache2/mods-available/ssl.load /etc/apache2/mods-enabled/ssl.load
sudo ln -s /etc/apache2/mods-available/ssl.conf /etc/apache2/mods-enabled/ssl.conf

# Enable Mod Rewrite by making a symlink:
sudo ln -s /etc/apache2/mods-available/rewrite.load /etc/apache2/mods-enabled/rewrite.load

# Restart apache to apply all the changes:
sudo /etc/init.d/apache2 restart

# Make directory for static resources
sudo mkdir /web

Run following command to be root:
sudo -s

Edit /etc/apache2/sites-enabled/000-default
Add following snippet to Virtual Host definition

	RewriteEngine On

	RewriteOptions inherit

Or simply delete /etc/apache2/sites-enabled

Export Path to the project (under root user):
export PROJECT_ROOT="/home/ialexeyenko/projects/jetstream"

PLEASE NOTE !! - PROJECT_ROOT is the actual path where Jestream project is located, you have to write your path there, from SAME terminal run the following commands:

Run following commands from the SAME terminal (under root user)
cd /web
ln -s  $PROJECT_ROOT/cms/target/cms-1.0/resource /web/cms_resource
ln -s  $PROJECT_ROOT/engine/target/engine-1.0/resource /web/engine_resource
ln -s  $PROJECT_ROOT/file/target/file-1.0 /web/file
ln -s  $PROJECT_ROOT/template/target/template-1.0/WEB-INF/template /web/template

Restart apache. Checkout http / https, check that static resources works on both protocols.
